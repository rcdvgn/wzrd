import { useState } from 'react'
import { ArrowIcon } from './components/Icons.jsx'
import './App.css';
import IntroPpt from './components/IntroPpt.jsx';
import Genre from './components/Genre.jsx';
import introCheck from './utils/progressChecks.js'

function App() {
  const [progress, setProgress] = useState(0);
  const prompts = [<IntroPpt />, <Genre />];
  const progressChecks = [];

  const handleBack = () => {
    progress ? setProgress(currentProgress => currentProgress - 1) : '';
  }
  const handleNext = () => {
    progress + 1 ? setProgress(currentProgress => currentProgress + 1) : '';
  }

  return (
    <>
      <div className="header"></div>
      <div className="content">
        <div className="mainContainer">
          <div className="progressTabs">
            {prompts.map((tab, index) => {
              return(
                <div key={index} className="progressTab"></div>
              )
            })}
          </div>
          <div className="mainContainerPrompt">
            <span className="mainContainerPromptTitle">Vamos começar, como você gostaria de ser chamado?</span>
          </div>
          {prompts[progress]}
          <div className="controls">
              <button className="nextBtn btn-1" onClick={handleBack}>
                <ArrowIcon className={'arrowIcon'} />
                Voltar
                  
              </button>
              <button className="nextBtn btn-1" onClick={handleNext}>
                Continuar
                <ArrowIcon className={'arrowIcon'} />
              </button>
          </div>
        </div>
      </div>
    </>
  )
}

export default App
