export function introCheck(){
    return false;
}