export default function Genre() {

    return (
        <h1>dfsdfsdf</h1>
    )
}