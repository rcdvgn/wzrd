import { useEffect, useRef } from 'react'



export default function IntroPpt(){

    const nameInput = useRef(null);

    const promptStyle = {
    }

    const handleBlur = () => {
        nameInput.current.focus();
    }
    
    useEffect(() => {
        nameInput.current.focus();
    }, []);

    return (
        <div 
            className="mainContainerBody"
            style={promptStyle}    
        >
            <input ref={nameInput} type="text" className="nameInput" onBlur={handleBlur} spellCheck={false} />
        </div>
    )
}